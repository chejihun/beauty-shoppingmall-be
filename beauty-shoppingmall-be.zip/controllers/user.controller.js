const User = require('../Model/User');
const bcrypt = require('bcryptjs')

const userController = {};

//회원가입
userController.createUser = async (req, res) => {
  try {
    let { email, password, name, level } = req.body
    const user = await User.findOne({ email })
    if (user) {
      throw new Error("이미 존재하는 이메일입니다.")
    }
    const salt = await bcrypt.genSaltSync(10)
    password = await bcrypt.hash(password, salt)
    const newUser = new User({ email, password, name, level: level ? level : 'customer' })
    await newUser.save()
    return res.status(200).json({ status: 'success' })

  } catch (error) {
    res.status(400).json({ status: 'fail', error: error.message })
  }
}

userController.getUser = async (req, res) => {
  try {
    const {userId} = req;
    const user = await User.findById(userId);
    if(user) {
      return res.status(200).json({status:'success', user });
    }
    throw new Error("유효하지 않은 토큰입니다");
  } catch (error) {
    res.status(400).json({ status: 'fail', error: error.message });
  }
};

module.exports = userController;